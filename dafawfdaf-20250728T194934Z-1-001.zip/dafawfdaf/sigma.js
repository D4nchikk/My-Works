document.getElementById('contact').addEventListener('submit', function(event) {
    alert("Am obtinut mesajul tau!");

    // Clear the form
    this.reset();
});




// Slideshow functionality
let currentSlide = 0;
const slides = document.querySelectorAll('.slide');
const dotsContainer = document.querySelector('.slideshow-dots');
const container = document.querySelector('.slideshow-container');

// Create dots
slides.forEach((_, index) => {
    const dot = document.createElement('div');
    dot.classList.add('dot');
    if (index === 0) dot.classList.add('active');
    dot.addEventListener('click', () => goToSlide(index));
    dotsContainer.appendChild(dot);
});

// Auto-advance slides every 5 seconds
let slideInterval = setInterval(() => moveSlide(1), 5000);

function moveSlide(direction) {
    // Reset the interval
    clearInterval(slideInterval);
    slideInterval = setInterval(() => moveSlide(1), 5000);

    currentSlide = (currentSlide + direction + slides.length) % slides.length;
    updateSlideshow();
}

function goToSlide(index) {
    currentSlide = index;
    updateSlideshow();
    // Reset the interval
    clearInterval(slideInterval);
    slideInterval = setInterval(() => moveSlide(1), 5000);
}

function updateSlideshow() {
    container.style.transform = `translateX(-${currentSlide * 100}%)`;
    
    // Update dots
    document.querySelectorAll('.dot').forEach((dot, index) => {
        dot.classList.toggle('active', index === currentSlide);
    });
}

// Pause slideshow on hover
container.addEventListener('mouseenter', () => clearInterval(slideInterval));
container.addEventListener('mouseleave', () => {
    clearInterval(slideInterval);
    slideInterval = setInterval(() => moveSlide(1), 5000);
}); 